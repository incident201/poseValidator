Android launcher icon resources generated from the uploaded image.

Copy the app/ directory from this archive into the repository root:
  incident201/poseValidator/

This will replace:
  app/src/main/res/mipmap-mdpi/ic_launcher.webp
  app/src/main/res/mipmap-mdpi/ic_launcher_round.webp
  app/src/main/res/mipmap-hdpi/ic_launcher.webp
  app/src/main/res/mipmap-hdpi/ic_launcher_round.webp
  app/src/main/res/mipmap-xhdpi/ic_launcher.webp
  app/src/main/res/mipmap-xhdpi/ic_launcher_round.webp
  app/src/main/res/mipmap-xxhdpi/ic_launcher.webp
  app/src/main/res/mipmap-xxhdpi/ic_launcher_round.webp
  app/src/main/res/mipmap-xxxhdpi/ic_launcher.webp
  app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.webp

Delete old adaptive/vector icon resources so Android 8+ does not continue using them:
  app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
  app/src/main/res/drawable/ic_launcher_background.xml
  app/src/main/res/drawable/ic_launcher_foreground.xml
